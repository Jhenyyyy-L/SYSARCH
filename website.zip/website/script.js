function selectRole(role) {
    document.getElementById('role').value = role;
}