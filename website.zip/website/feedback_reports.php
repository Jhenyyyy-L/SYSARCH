<?php
// At the top of your PHP file, include your database configuration
include 'db_config.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $feedback_content = $_POST['feedback_content'];

    // Prepare the SQL statement
    $sql = "INSERT INTO feedback (feedback_content) VALUES (?)";

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    // Bind the parameter
    $stmt->bind_param("s", $feedback_content);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Feedback submitted successfully.";
    } else {
        echo "Error: ". $sql. "<br>". $conn->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback and Reporting</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<style>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap");
*{
    margin: 0;
    padding: 0;
    border: none;
    outline: none;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

body {
    background-color: white;
    margin: 0;
    padding: 0;
}

.sidebar {
    background-color: black;
    color: white;
    width: 250px;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    overflow-y: auto;
    z-index: 999;
}

.sidebar .logo {
    padding: 20px;
    text-align: center;
}

.sidebar .logo span {
    display: block;
    margin-top: 10px;
    font-size: 18px;
}

.sidebar .menu {
    padding: 0;
    margin: 0;
    list-style: none;
}

.sidebar .menu li {
    padding: 15px 20px;
    border-bottom: 1px solid #333;
}

.sidebar .menu li.active {
    background-color: #333;
}

.sidebar .menu li a {
    color: white;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.sidebar .menu li a i {
    margin-right: 10px;
}

.container {
    margin-left: 30%;
    margin-top: 5%;
    width: 50%; /* Adjust width as needed */
}

.input {
    font-weight: 500;
    font-size: 14px;
    height: 40px;
    width: 100%;
    border-radius: 10px;
    padding-left: 10px;
    border: none;
    border-bottom: 1px solid #e5e5e5;
    outline: none;
    margin-top: 20px;
    text-decoration: none;
}

.input:focus {
    border-bottom: 1px solid #6941c6;
    transition: border-bottom 0.5s;
}

.button {
    display: inline-block;
    border-radius: 4px;
    background-color: #3d405b;
    border: none;
    color: #FFFFFF;
    text-align: center;
    font-size: 14px;
    padding: 12px;
    width: 160px;
    transition: all 0.5s;
    cursor: pointer;
    margin: 5px;
    margin-top: 5px;
    text-decoration: none;
}

.button span {
    cursor: pointer;
    display: inline-block;
    position: relative;
    transition: 0.5s;
    text-decoration: none;
}

.button span:after {
    content: '»';
    position: absolute;
    opacity: 0;
    top: 0;
    right: -15px;
    transition: 0.5s;
}

.button:hover span {
    padding-right: 15px;
}

.button:hover span:after {
    opacity: 1;
    right: 0;
}
</style>
<div class="sidebar">
    <div class="logo">
        <span>CCS SIT-IN <br> MONITORING SYSTEM</span>
    </div>
    <br>
    <ul class="menu">
            <li><a href="student_dashboard.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></li>
            <li><a href="edit_profile.php"><i class="fas fa-user"></i><span>Profile</span></li>
            <li><a href="remaining_sessions.php"><i class="fas fa-calendar-check"></i><span>View Remaining Session</span></li>
            <li><a href="sitin_history.php"><i class="fas fa-history"></i><span>Sitin Logs</span></li>
            <li class="active"><a href="feedback_reports.php"><i class="fa-solid fa-flag"></i><span>Feedback and Reporting</span></a></li>
            <li><a href="safety.php"><i class="fa-solid fa-user-shield"></i><span>Safety Monitoring/Alert</span></a></li>
            <li><a href="view_announcement.php"><i class="fa-solid fa-scroll"></i><span>View Announcement</span></a></li>
            <li><a href="future_reservation.php"><i class="fa-solid fa-bookmark"></i><span>Future Reservations</span></a></li>
            <li><a href="lab_rules.php"><i class="fa-solid fa-circle-info"></i></i><span>Lab Sitin Rules</span></a></li>
            <li class="logout"><a href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></li>
        </ul>
    </div>
    <form method="post" action="submit_feedback.php">
    <input type="text" name="feedback_content" placeholder="Type feedback here...">
    <br>
    <button type="submit" class="button">Submit Feedback</button>
</form>
    </div>
</body>
</html>